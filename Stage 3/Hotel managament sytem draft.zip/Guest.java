import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
  

class Guest {//another tester program 
    private String name;
    private String membership;

    public Guest(String name, String membership) {
        this.name = name;
        this.membership = membership;
    }

    public String getName() {
        return name;
    }

    public String getMembership() {
        return membership;
    }
}
