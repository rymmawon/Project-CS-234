import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Hotel {
    private List<Guest> guests = new ArrayList<>();
    private Room roomType;
    private List<Employee> employees = new ArrayList<>(); // Add employees list

    public Hotel() {
        roomType = new Room();
        roomType.setRoomPrice(110);
        // Initialize employees here if needed
    }

    public static void main(String[] args) {
        System.out.print("Welcome to our hotel\n");
        System.out.print("1.Employee Check in\n2.Check in\n3.Check Out\n4.");
        Scanner scanner = new Scanner(System.in);
        int choice = scanner.nextInt();
       
        
        Hotel hotel = new Hotel();
        hotel.guests.add(new Guest("Joe", null));

        // Create employees and add them to the hotel's staff
        Employee employee1 = new Employee(1, "John", "Doe", 30);
        Employee employee2 = new Employee(2, "Alice", "Smith", 25);
        hotel.employees.add(employee1);
        hotel.employees.add(employee2);

        Reservation hotelReservation = new Reservation();
        Reservation hotel1 = new Reservation();
        int roomPrice = hotel1.checkIn("Julian", scanner, hotel.roomType);

        hotel.now(roomPrice);

        scanner.close();
    }


    public void now(int roomPrice) {
        // Use the same list of guests
        Services hotelServices = new Services(guests);

        
        Scanner scanner = new Scanner(System.in);

        System.out.print("Would you like a service?");
        String choice = scanner.nextLine();
        Services gettotal = new Services(guests);
        if(choice.equalsIgnoreCase("Yes")){
            hotelServices.displayAvailableServices();
            System.out.print("Enter the service you want: ");
            String userChoice = scanner.nextLine();
        if (userChoice.equalsIgnoreCase("Pool") || userChoice.equalsIgnoreCase("Gym") ||
            userChoice.equalsIgnoreCase("Free Wifi") || userChoice.equalsIgnoreCase("Free Parking")) {
            System.out.println("\nYou chose " + userChoice + ", a default free service");

            for (Guest guest : guests) {
                gettotal.addAllFees(0.0f, guest, roomPrice);
            }
        } else if (userChoice.equalsIgnoreCase("Room Service")) {
            System.out.println("You chose a paid service");
           gettotal.checkMembership(roomPrice);
        } else {
            System.out.println("Service not found");
            // Handle the case where the service is not found or not free.
        }
    }
    else {
        System.out.print("No service selected.\n");
        for (Guest guest : guests) {
            gettotal.addAllFees(0.0f, guest, roomPrice);
        }
        }
    
        scanner.close();
    }
}