import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Membership {
    private String membershipID;

    public Membership(String membershipID) {
        this.membershipID = membershipID;
    }

    public String getMembershipID() {
        return membershipID;
    }
}






