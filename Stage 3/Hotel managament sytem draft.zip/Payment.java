import java.util.ArrayList;
import java.util.List;

public class Payment {//Julian Marquez
    private double paymentAmount;

    public Payment(double paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    public double getPaymentAmount() {
        return paymentAmount;
    }

    public void setPaymentamount(double paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    public void paymentDetails() {

    System.out.println("Payment of $"+this.getPaymentAmount());

    }
}
 