import java.util.ArrayList;

public class User {
    private ArrayList<Room> rooms;
    private ArrayList<Reservation> reservations;
    private ArrayList<Guest> guests;
    private ArrayList<Invoice> receipts;

    public User() {
        rooms = new ArrayList<>();
        reservations = new ArrayList<>();
        guests = new ArrayList<>();
        receipts = new ArrayList<>();
    }

    public void addReservation(Reservation reservation) {
        reservations.add(reservation);
    }

    public Reservation searchReservation(String reservationId) {
        // Implement code to search for a reservation by ID
        return null;
    }

    public Guest searchGuest(String guestName) {
        // Implement code to search for a guest by name
        return null;
    }

    public void editGuestInfo(Guest guest) {
        // Implement code to edit guest information
    }

    public void removeGuest(Guest guest) {
        guests.remove(guest);
    }

    public int searchRoom(String roomNumber) {
        // Implement code to search for a room by number and return its index
        return -1;
    }

    public void editRoom(Room room) {
        // Implement code to edit room information
    }

    public void deleteRoom(Room room) {
        rooms.remove(room);
    }

    public Employee searchEmployee(String employeeName) {
        // Implement code to search for an employee by name
        return null;
    }
}
